# Markdown timer
## A timer based on markdown syntax
+ A small website for executing written markdown as timers

Eg. "5 min: read code"

Then the next instruction will be added to the set of timers and you will have a list. 

# TDL
+ Add video that one can watch at the same time (for exercies)
+ Add it so that the app correctly converts minutes to hours
+ Make it so that the first letter always is a captilized letter
